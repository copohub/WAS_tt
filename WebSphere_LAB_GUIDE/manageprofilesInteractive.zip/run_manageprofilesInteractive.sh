#!/bin/sh

# All Rights Reserved * Licensed Materials - Property of IBM
# 5724-I63, 5724-H88, 5655-N01, 5733-W60 (C) COPYRIGHT International Business Machines Corp., 1997,2005
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.

# For WebSphere v6.1  use "v61" as parameter
# For WebSphere v7.0  use anything else, e.g. "v70"

binDir=`dirname $0`
. $binDir/setupCmdLine.sh

# ${JAVA_HOME}/bin/java -jar manageprofilesInteractive.jar v61
${JAVA_HOME}/bin/java -jar manageprofilesInteractive.jar v70